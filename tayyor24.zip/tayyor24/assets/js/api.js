const API = {
    DATA: null,
    
    init: function() {
        try {
            // Mahalliy ma'lumotlarni yuklash
            if(localStorage.getItem('tayyor24_data')) {
                this.DATA = JSON.parse(localStorage.getItem('tayyor24_data'));
            } else {
                this.DATA = {
                    settings: { api_key: "tayyor24_apikey_123456" },
                    restaurants: [],
                    orders: [],
                    promo_codes: []
                };
            }
            return true;
        } catch (error) {
            console.error("Init error:", error);
            return false;
        }
    },
    
    saveData: function() {
        localStorage.setItem('tayyor24_data', JSON.stringify(this.DATA));
    },
    
    // Misol funksiya
    addRestaurant: function(restaurantData) {
        this.init();
        const newRestaurant = {
            id: this.DATA.restaurants.length + 1,
            ...restaurantData
        };
        this.DATA.restaurants.push(newRestaurant);
        this.saveData();
        
        // Bu yerda ma'lumotlarni faylga yozish funktsiyasini chaqirish mumkin
        this.exportToFile();
        
        return newRestaurant;
    },
    
    exportToFile: function() {
        const dataStr = JSON.stringify(this.DATA, null, 2);
        const blob = new Blob([dataStr], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = 'db.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
};

// Admin panelida saqlash tugmasi
document.addEventListener('DOMContentLoaded', () => {
    const saveBtn = document.createElement('button');
    saveBtn.textContent = 'Ma\'lumotlarni Saqlash';
    saveBtn.style.position = 'fixed';
    saveBtn.style.bottom = '20px';
    saveBtn.style.right = '20px';
    saveBtn.style.zIndex = '1000';
    saveBtn.style.padding = '10px';
    saveBtn.style.background = '#ff6b00';
    saveBtn.style.color = 'white';
    saveBtn.style.border = 'none';
    saveBtn.style.borderRadius = '5px';
    saveBtn.style.cursor = 'pointer';
    
    saveBtn.addEventListener('click', () => {
        API.exportToFile();
        alert('db.json fayliga saqlandi!');
    });
    
    document.body.appendChild(saveBtn);
});